import java.util.ArrayList;

/*
Item.java
This class represents an item that can be interacted with by the player.  
*/
public class Item {
    String name;
    boolean embeded;
    String shortDesc;
    String description;
    ArrayList<String> status = new ArrayList<String>();

    public Item (){};
    
    public Item(String n, String d){
        name = n;
        embeded = false;
        shortDesc = d;
    }

    public String getDesc() {
        return description;
    }
}