import java.util.Random;
public class Player {
    Random rand = new Random();
    String name;
    int playerhealth = 100;
        int attackDamage = 30;
        int numHealthPots = 3;
        int healthPotionsHealAmount = 25;
        int healthPotionDropCahnce = 50; // percentage

        int animalAttackDamage = 30;

        int damageDealt = rand.nextInt(attackDamage);
        int damageTaken = rand.nextInt(animalAttackDamage);
        

        public Player(){};
}
