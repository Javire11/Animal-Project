import java.util.*;


public class Location {

String name;
String description;
Location north;
Location east;
Location south;
Location west;

Entity animalHere;

Player userHere;

Item itemHere;

Inventory storeInv;

Item[] items = new Item[7];

public  Location(){};



}