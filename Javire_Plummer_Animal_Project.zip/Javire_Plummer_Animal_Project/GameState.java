import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
/*
GameState.java
This is the class to hold the state of the running game and allows easy
passing of important information to methods that require data from the
state of the game.
*/


public class GameState {

    Random rand = new Random();
    Location currentLocation;
    Location[] places = new Location[6];

    Player human;

    Location walkway;
    Location darkCave;
    Location lightCave;
    Location river;
    Location forest;
    Location treeStump;
    Location cabin;

    Entity Bear;
    Entity Wolf;
    Entity Bee;
    Entity Spider;
    Entity Alligator;

    CommandSystem commandSystem;

    String item;
    Item knife;
    Item sticks;
    Item mushrooms;
    Item bushes;
    Item berries;
    Item fire;
    Item water;
    Item mat;  

    Inventory invSlot;
    
    
    public static int DISPLAY_WIDTH = 80;

    /*
        GameState Constructor

        Ideally, your game will be fully loaded and ready to play once this constructor has finished running.

        How things have been done here are just a rudementry setup to link the other classes and have the 
        bare bones example of the command system. This is not a great way to initilize your project.

        You should do better!
    */
    public GameState(){
        commandSystem = new CommandSystem(this);
        // Player

        int attackDamage = 30;
        int numHealthPots = 3;
        int healthPotionsHealAmount = 25;
        int healthPotionDropCahnce = 50; // percentage

        human = new Player();
        human.name = "User";
        human.playerhealth = 100;
        human.attackDamage = 20;
        commandSystem.addNoun("user");
        System.out.println("\t Your HP is: " + human.playerhealth);

        // Animal Health
        int maxEntityHealth = 80;
        int score = 1;
        int animalAttackDamage = 30;

        int damageDealt = rand.nextInt(attackDamage);
        int damageTaken = rand.nextInt(animalAttackDamage);

        
        // Create first (starting) location 
        // (and store it in currentLocation so I can always referece where the player is easily)
        walkway = new Location();
        walkway.name = "Front of [Walkway]";
        walkway.description = "You are standing om the walkway in the begining of woods";
        commandSystem.addNoun ("path");
        commandSystem.addNoun("pick up");
        currentLocation = walkway;

        darkCave = new Location();
        Bear = new Entity();
        darkCave.name = "dark cave";
        darkCave.description = "You are standing in front of the dark cave.";
   

        lightCave = new Location();
        lightCave.name = "light Cave";
        lightCave.description = "You are standing in front of the light cave. This can be good for shelter or somewhere to hide and there is no animmals in here as all the animals go searching for food";
        commandSystem.addNoun("safecave");

        river = new Location();
        river.name = " River ";
        river.description = "You are standing in front of the river. You can swim away or fill up your water bottle"; 
        commandSystem.addNoun("river");

        forest = new Location();
        forest.name = "Front [forest]";
        forest.description = "You are in front of the forest. It's trees, branches, leaves, and sounds everywhere, you step on something sharp";
        knife = new Item();
        knife.description = "There is a pocket knife on the ground. Looks Rusty.";
        commandSystem.addNoun("forest");
        commandSystem.addNoun("knife");

        treeStump = new Location();
        treeStump.name = "Front [treeStump]";
        treeStump.description = "You are on the front of the tree stump. There seems to be footprints left here"; 
        commandSystem.addNoun("treestump");

        cabin = new Location();
        cabin.name = "Front of [Cabin]";
        cabin.description = "You found a wore down cabin";
        commandSystem.addNoun("cabin");

        walkway.north = forest;
        walkway.south = cabin;
        walkway.east = river;
        walkway.west = darkCave;

        forest.north = treeStump;
        forest.south = walkway;
        forest.east = river;
        forest.west = treeStump;

        treeStump.north = river;
        treeStump.south = forest;
        treeStump.east = lightCave;
        treeStump.west = forest;

        lightCave.north = null;
        lightCave.south = treeStump;
        lightCave.west = treeStump;
        lightCave.east = river;

        darkCave.north = null;
        darkCave.south = forest;
        darkCave.east = walkway;
        darkCave.west = river;

        cabin.north = walkway;
        cabin.south = null;
        cabin.west = forest;
        cabin.east = river;

        river.north = lightCave;
        //river.
        river.south = cabin;
        river.east = treeStump;
        river.west = forest;

        

        // currentLocation.north = darkCave;
        // currentLocation.south = lightCave;

        // Item attack variable
        int weaponDamage = 35;
        int weaponHealth = 70;


        // Create a demo item.
        Item mat = new Item();
        mat.name = "Mat";
        mat.description = "There is a welcome mat here. This is a special mat.";


        Item knife = new Item();
        knife.name = "PocketKnife";
        knife.description = "There is a pocket knife on the ground. Looks Rusty.";
        cabin.itemHere = knife;
        commandSystem.addNoun("pocketknife");
        commandSystem.addNoun("attack");
        //inventoryLocation.items[0] = knife;

        Item mushrooms = new Item();
        mushrooms.name = "Mysterious Mushrooms";
        mushrooms.description = "There's some mushrooms on the floor. Looks shiny.";
        walkway.itemHere = mushrooms;
        commandSystem.addNoun("mushrooms");
        //inventoryLocation.items[0]= mushrooms;

        Item berries = new Item();
        berries.name = "Wild Berries";
        berries.description = "There are some berries on the bushes.";
        treeStump.itemHere = berries;
        commandSystem.addNoun("berries");
        //inventoryLocation.items[0]= mushrooms;

        bushes = new Item();
        bushes.name = "Bushes";
        bushes.description = "There are some bushes with some berries on it.";
        forest.itemHere = bushes;
        commandSystem.addNoun("bushes");
        //inventoryLocation.items[0]= berries;

        water = new Item();
        water.name = "water";
        water.description= "You discovered water";
        river.itemHere = water;
        commandSystem.addNoun("water");
        //inventoryLocation.items[0]= water;

        sticks = new Item();
        sticks.name = "sticks";
        sticks.description = "You found sticks";
        darkCave.itemHere = sticks;
        commandSystem.addNoun("sticks");
        //inventoryLocation.items[0]= sticks

        // Animals
        Bear = new Entity();
        Bear.name = " Grizzly Bear";
        Bear.health = 95;
        Bear.description = " You found a angry " + Bear.name + ", who has " + Bear.health + " amount of HP: ";
        Bear.animalAttackDamage = rand.nextInt(animalAttackDamage);
        forest.animalHere = Bear;
        commandSystem.addNoun("bear");

        Alligator = new Entity();
        Alligator.name = "Alligator";
        Alligator.health = 70;
        Alligator.description = " You found a " + Alligator.name + ", who has " + Alligator.health + " amount of health";
        Alligator.animalAttackDamage = rand.nextInt(animalAttackDamage);
        commandSystem.addNoun("alligator");
        river.animalHere = Alligator;

        Bee = new Entity();
        Bee.name = "Bee";
        Bee.health = 40;
        Bee.description = "You found a yellow" + Bee.name + ", who has " + Bee.health + " amount of health";
        Bee.animalAttackDamage = rand.nextInt(animalAttackDamage);
        treeStump.animalHere = Bee;
        commandSystem.addNoun("bee");
        
        Spider = new Entity();
        Spider.name = "Spider";
        Spider.health = 50;
        Spider.description = "You found a Giant " + Spider.name + ", who has " + Spider.health + " amount of health";
        Spider.animalAttackDamage = rand.nextInt(animalAttackDamage);
        cabin.animalHere = Spider;
        commandSystem.addNoun("spider");

        Wolf = new Entity();
        Wolf.name = "WereWolf";
        Wolf.health = 60;
        Wolf.animalAttackDamage = 30;
        Wolf.animalAttackDamage = rand.nextInt(animalAttackDamage);
        Wolf.description = "You found a " + Wolf.name + ", who came out the dark cave, the wolf  has a " + Wolf.health + " amount of health";
        darkCave.animalHere = Wolf;
        commandSystem.addNoun("wolf");


        // Player Variables
        human = new Player();
        human.name = "User";
        human.playerhealth = 100;
        human.attackDamage = rand.nextInt(attackDamage);
        commandSystem.addNoun("user");

        invSlot = new Inventory();


        

        //Add item to list of nouns so our command system knows it exists.
        commandSystem.addNoun(walkway.name);
        commandSystem.addNoun(darkCave.name);
        commandSystem.addNoun(lightCave.name);
        commandSystem.addNoun(river.name);
        commandSystem.addNoun(forest.name);
        commandSystem.addNoun(treeStump.name);
        commandSystem.addNoun(cabin.name);
        commandSystem.addNoun(knife.name);
        commandSystem.addNoun(mushrooms.name);
        commandSystem.addNoun(berries.name);
        commandSystem.addNoun(bushes.name);
        commandSystem.addNoun(water.name);
        commandSystem.addNoun(sticks.name);

    





        /* 
            Once the commandSystem knows about the item, we need to code what happens with each of the commands that can happen with the item.
            See CommandSystem line 64 for what happens if you currently "look mat"
        */
    }
}
