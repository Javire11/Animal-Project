public class Inventory {
    String name;
    String description;
    
    Inventory[] slot = new Inventory[4];
    
    
    public Inventory(){};
    }
