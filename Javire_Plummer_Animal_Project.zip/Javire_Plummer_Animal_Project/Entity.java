public class Entity {
    String name;
    String description;
    int health = 100;
    int animalAttackDamage = 30;
    

    Entity[] animal = new Entity[4];

    public String getDesc() {
        return description;
    }



    public Entity(){};

}
